const SpeechRecognition =
    window.SpeechRecognition ||
    window.webkitSpeechRecognition;

const status = document.getElementById("status");
const text = document.getElementById("text");
const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");

// Wake word - just say "Nova" (or "Noah") at the start of the
// command. Also still accepts "hey nova", "innova", "in nova",
// "hey noah", etc. so common mishearings keep working.
const WAKE_PATTERNS = [
    /^nova\b/i,
    /^novas\b/i,
    /^nsa\b/i,
    /^hey\s*nova\b/i,
    /^hey\s*novas\b/i,
    /^hi\s*nova\b/i,
    /^in\s*nova\b/i,
    /^innova\b/i,
    /^ay\s*nova\b/i,
    /^a\s*nova\b/i,
    /^eh\s*nova\b/i,

    // Noah (common mishearing of Nova)
    /^noah\b/i,
    /^noa\b/i,
    /^hey\s*noah\b/i,
    /^hey\s*noa\b/i,
    /^hi\s*noah\b/i,
    /^in\s*noah\b/i,
    /^innoah\b/i,
    /^eh\s*noah\b/i
];

let assistantRunning = false;
let recognitionRunning = false;
let restartTimer = null;
let lastGreetTime = 0;
let lastSpokenText = "";
let cancelled = false;

const recognition = new SpeechRecognition();

recognition.continuous = true;
recognition.interimResults = true;
recognition.lang = "en-US";
recognition.maxAlternatives = 5;


// ======================================
// START BUTTON
// ======================================

startBtn.addEventListener("click", () => {

    if (assistantRunning) {
        return;
    }

    assistantRunning = true;
    cancelled = false;

    status.textContent =
        "🟢 Listening for Hey Nova...";

    startRecognition();
});


// ======================================
// STOP BUTTON
// ======================================

stopBtn.addEventListener("click", () => {

    stopAssistant();

});


// ======================================
// START RECOGNITION
// ======================================

function startRecognition() {

    if (!assistantRunning) {
        return;
    }

    if (recognitionRunning) {
        return;
    }

    try {

        recognition.start();

        recognitionRunning = true;

        status.textContent =
            "🟢 Listening for Hey Nova...";

        console.log("🎙️ Recognition started");

    } catch (error) {

        console.log(
            "Recognition start:",
            error
        );

        recognitionRunning = false;
    }
}


// ======================================
// AUTO-RESTART
// ======================================

// Chrome's speech engine drops the mic on its own
// (after ~30-60s, when the tab is backgrounded, or on
// silent/aborted events). This reconnects it quickly
// so the assistant keeps hearing you in other tabs.

function scheduleRestart() {

    if (!assistantRunning) {
        return;
    }

    clearTimeout(restartTimer);

    restartTimer = setTimeout(() => {

        if (assistantRunning) {

            // Clear any leftover speech so the mic is ready.
            try {
                speechSynthesis.cancel();
            } catch (e) {
                console.log(e);
            }

            startRecognition();
        }

    }, 120);
}


// ======================================
// SPEECH RESULT
// ======================================

recognition.onresult = (event) => {

    let spokenText = "";
    let hasFinal = false;

    for (
        let i = event.resultIndex;
        i < event.results.length;
        i++
    ) {

        // Pick the LONGEST candidate transcription - the mic
        // sometimes drops the wake word, so using the most
        // complete alternative helps catch "nova open amazon"
        // instead of just "open amazon".
        const candidates = event.results[i];

        let best = "";

        for (const alt of candidates) {
            if (alt.transcript.length > best.length) {
                best = alt.transcript;
            }
        }

        spokenText += best + " ";

        if (candidates.isFinal) {
            hasFinal = true;
        }
    }


    spokenText =
        spokenText
            .toLowerCase()
            .trim();


    // ECHO SUPPRESSION: the mic often picks up Nova's own voice
    // and hears her last reply as a brand-new user command. So
    // if the recognized words are really just her last reply
    // (significant word overlap) WITHOUT a wake word, ignore it
    // completely - no cancel, no display, no action. This stops
    // her reply from sitting in "You said" or making her repeat.
    function isEcho(spoken) {
        if (!lastSpokenText) {
            return false;
        }
        // Common, tiny, or feedback-only words that SHOULD NOT
        // block a real command. Without this, "scroll down"
        // gets mistaken for Nova's own "Scrolling down"
        // feedback and ignored, so you couldn't scroll twice.
        const ignored = new Set([
            "up", "down", "here", "this", "tab", "yes", "sir",
            "stopped", "the", "for", "and", "you", "nova"
        ]);
        const words = lastSpokenText
            .split(/\s+/)
            .filter(w => w.length >= 4 && !ignored.has(w.toLowerCase()));
        if (!words.length) {
            return false;
        }
        return words.some(w => spoken.includes(w));
    }

    const hasWakeWord =
        /nova|noah|innova/.test(spokenText);

    if (!hasWakeWord && isEcho(spokenText)) {
        return;
    }


    // BARGE-IN but only on REAL speech. Background noise and
    // tiny sounds also fire interim results, so we only cut
    // Nova off when there are a couple of real words - not on
    // noise, one stray word, or Nova's own voice.
    const wordCount = spokenText ? spokenText.split(/\s+/).length : 0;

    if (wordCount >= 2 && speechSynthesis.speaking) {
        try {
            speechSynthesis.cancel();
        } catch (e) {
            console.log(e);
        }
    }


    console.log(
        "Heard:",
        spokenText
    );


    // Live "You said" box. Use the FULL current utterance
    // (built from resultIndex) so speed issues don't replace
    // "nova" with its tail - e.g. "nova open youtube" appears
    // whole instead of "nova" being swapped for "open".
    if (spokenText) {
        text.textContent = spokenText;
    }


    // ==================================
    // NORMALIZE SPEECH
    // ==================================

    // Converts:
    // "hey, nova, stop"
    //
    // into:
    // "hey nova stop"
    //
    // and spoken URLs like "discord dot gg" into "discord.gg"
    // (the word "dot" becomes a real "." with no spaces).

    const normalizedText =
        spokenText
            .replace(/[,!?]/g, " ")
            .replace(/\bdot\b/g, ".")
            .replace(/\s*\.\s*/g, ".")
            .replace(/\s+/g, " ")
            .trim();


    console.log(
        "Normalized:",
        normalizedText
    );


    // ==================================
    // WAKE WORD (fuzzy)
    // ==================================

    // Matches "nova", "noah", "hey nova", "innova", etc.
    // at the START of the sentence and returns the
    // length of the matched wake words, or 0 if not found.

    function wakeLength(text) {

        for (const re of WAKE_PATTERNS) {

            const m = text.match(re);

            if (m && m.index === 0) {
                return m[0].length;
            }
        }

        return 0;
    }

    let command = normalizedText;
    let cut = wakeLength(command);

    if (!cut) {
        return;
    }

    // Strip any repeated wake words at the front
    // (e.g. "nova nova open youtube").
    while (cut > 0) {
        command = command.slice(cut).replace(/^\s+/, "");
        cut = wakeLength(command);
    }

    // If only the wake word was heard, do nothing.
    if (!command) {
        return;
    }


    // ==================================
    // GREETING / STATUS CHECK
    // ==================================
    // Responds instantly - even on "live" results - so it
    // feels fast and doesn't wait for the phrase to finish.

    if (
        /^(are you awake|are you there|hello|hi|hey|yo)\b/i.test(command) ||
        /^(is|are) you (awake|there|here|on|up)\b/i.test(command)
    ) {

        // Only reply once per phrase - interim ("live") results
        // fire many times, so this stops Nova repeating itself.
        const now = Date.now();

        if (now - lastGreetTime < 1500) {
            return;
        }

        lastGreetTime = now;

        const reply = "Yes sir";

        result.textContent = reply;

        speak(reply);

        text.textContent = command;

        return;
    }


    // ==================================
    // STOP COMMAND
    // ==================================
    // Responds instantly so "nova stop" always works.

    if (
        /^stop(\s|$)/i.test(command) ||
        /^stop\s+(listening|assistant)(\s|$)/i.test(command)
    ) {

        console.log(
            "🛑 STOP COMMAND DETECTED"
        );

        // Speak the confirmation BEFORE stopping, so the
        // assistant's shutdown doesn't cancel it.
        speak("Stopped");

        text.textContent = command;

        result.textContent = "Stopped";

        stopAssistant(true);

        return;
    }


    // ==================================
    // NORMAL COMMANDS
    // ==================================
    // Regular commands wait for the finished phrase so we
    // don't execute on a half-spoken word. ("Live" interim
    // results above are still handled instantly.)

    if (!hasFinal) {
        return;
    }


    text.textContent = command;

    executeCommand(command);
};


// ======================================
// RECOGNITION ENDED
// ======================================

recognition.onend = () => {

    console.log(
        "Recognition ended"
    );


    recognitionRunning = false;


    // VERY IMPORTANT:
    // If stopped, NEVER restart.

    if (!assistantRunning) {

        status.textContent =
            "🔴 Assistant stopped";

        return;
    }


    status.textContent =
        "🟡 Restarting...";


    scheduleRestart();
};


// ======================================
// SPEECH ERROR
// ======================================

recognition.onerror = (event) => {

    console.log(
        "Speech error:",
        event.error
    );


    recognitionRunning = false;


    if (!assistantRunning) {
        return;
    }


    if (
        event.error === "no-speech" ||
        event.error === "aborted" ||
        event.error === "network" ||
        event.error === "audio-capture"
    ) {

        // Transient errors - reconnect the mic so the
        // assistant keeps listening in other tabs.
        status.textContent =
            "🟡 Reconnecting...";

        scheduleRestart();

        return;
    }


    status.textContent =
        "Error: " + event.error;

    // Hard errors (not-allowed, service-not-allowed) -
    // keep trying after a short pause.
    scheduleRestart();
};


// ======================================
// STOP ASSISTANT
// ======================================

function stopAssistant(skipSpeechCancel) {

    console.log(
        "🛑 STOPPING ASSISTANT"
    );


    // Cancel any in-flight command so it won't keep running
    // or speak "sorry, couldn't do that" after we stopped.
    // (skipSpeechCancel is only used by the "stop" voice
    // command, so the "Stopped" confirmation gets to play.)

    cancelled = true;

    if (!skipSpeechCancel) {
        try {
            speechSynthesis.cancel();
        } catch (e) {
            console.log(e);
        }
    }


    // FIRST disable automatic restart

    assistantRunning = false;


    // Cancel pending restart

    clearTimeout(restartTimer);

    restartTimer = null;


    // Mark recognition as stopped

    recognitionRunning = false;


    try {

        recognition.abort();

    } catch (error) {

        console.log(error);

    }


    status.textContent =
        "🔴 Assistant stopped";

    text.textContent =
        "Assistant stopped";


    console.log(
        "🛑 Assistant completely stopped"
    );
}


// ======================================
// COMMAND EXECUTOR
// ======================================

const BACKEND_URL =
    "http://localhost:3000";

const result = document.getElementById("result");

// ======================================
// LOCAL AI BACKEND DETECTION
// ======================================
// The extension works 100% offline with the built-in command resolver.
// If the user also runs our local AI server (http://localhost:3000),
// it auto-DETECTS the API and switches over so natural-language
// commands use AI. Server starts later? The checker keeps probing
// every few seconds and quietly moves the extension to AI the moment
// it comes online.

let aiOnline = false;
let aiProbeTimer = null;

async function probeBackend() {

    try {

        const controller = new AbortController();
        const timer = setTimeout(
            () => controller.abort(),
            3000
        );

        const response = await fetch(
            BACKEND_URL + "/",
            { signal: controller.signal }
        );

        clearTimeout(timer);

        const data = await response.json().catch(() => ({}));

        aiOnline = Boolean(
            response.ok &&
            data &&
            data.success
        );

    } catch (error) {

        aiOnline = false;
    }

    updateAiStatus();

    return aiOnline;
}

function updateAiStatus() {

    const el = document.getElementById("aiStatus");

    if (!el) {
        return;
    }

    el.textContent =
        aiOnline
            ? "AI online"
            : "AI offline · built-in commands";

    el.className =
        "ai-chip " +
        (aiOnline ? "ai-on" : "ai-off");
}

// Check once when the page loads, then quietly re-probe while the
// server is offline so turning the AI on mid-session is picked up.
probeBackend();

aiProbeTimer = setInterval(() => {

    if (!aiOnline) {
        probeBackend();
    }

}, 15000);


// Sends the command to the AI backend, then
// executes whatever action the AI returns.

async function executeCommand(command) {

    console.log(
        "Executing:",
        command
    );

    // STEP 0 - split compound commands
    // ("open yt and search carryminate" -> two actions)
    // and run them one after another.

    const subCommands = splitCommands(command);

    let allFailed = true;
    const messages = [];

    for (const sub of subCommands) {

        const outcome = await executeSingle(sub);

        if (outcome.ok) {
            allFailed = false;
            messages.push(outcome.message);
        }
    }

    // If a "stop" happened mid-command, don't speak any
    // feedback (including "couldn't do that") - user wants
    // silence and no leftover task continuing.
    if (cancelled) {
        return;
    }

    if (allFailed) {
        speak("Sorry, I couldn't do that");
        result.textContent = "Couldn't do that";
        return;
    }

    const message = messages.join(". ");

    result.textContent = message;

    speak(message);
}

// Turns "open yt and search carryminate" into
// ["open yt", "search carryminate"].
// Only splits where the following part actually starts
// with a command word, so normal sentences stay whole.

const ACTION_STARTERS = [
    /^open\b/i, /^go\s+to\b/i, /^go\s+back\b/i, /^go\s+forward\b/i,
    /^take\s+me\s+to\b/i, /^visit\b/i, /^launch\b/i, /^start\b/i,
    /^search\b/i, /^look\s+up\b/i, /^find\b/i, /^play\b/i, /^watch\b/i,
    /^close\b/i, /^scroll\b/i, /^reload\b/i, /^refresh\b/i,
    /^new\s+tab\b/i, /^navigate\s+to\b/i, /^open\s+up\b/i
];

function splitCommands(command) {

    const raw = String(command).trim();

    const rawParts = raw
        .split(/\s+(?:and|then)\s+|\s*,\s*/i)
        .map((s) => s.trim())
        .filter(Boolean);

    if (rawParts.length < 2) {
        return [raw];
    }

    const result = [rawParts[0]];

    for (let i = 1; i < rawParts.length; i++) {

        const cur = rawParts[i];
        const prevIdx = result.length - 1;

        if (ACTION_STARTERS.some((r) => r.test(cur))) {

            result.push(cur);

        } else {

            // Not a command start - merge back into the
            // previous part so we don't break the sentence.
            result[prevIdx] = result[prevIdx] + " " + cur;
        }
    }

    return result.filter(Boolean);
}

// Runs ONE command: local resolution, then the AI backend.
// Returns { ok, message }.

async function executeSingle(command) {

    // If we stopped, don't run anything (no searching, no
    // opening tabs, no backend calls).
    if (cancelled) {
        return { ok: false, message: "Cancelled" };
    }

    // STEP 1 - fast local resolution.
    // Most commands are "open X", "search X", "go back", etc.
    // and can be answered instantly with zero network round-trip.

    const localAction = resolveLocally(command);

    if (localAction) {

        if (cancelled) {
            return { ok: false, message: "Cancelled" };
        }

        const executed =
            runAction(localAction);

        if (executed) {
            return {
                ok: true,
                message: describeAction(localAction)
            };
        }

        return { ok: false, message: "Unsupported action" };
    }

    // STEP 2 - AI backend, but ONLY when the AI server is actually
    // running. If it's offline we never wait for a dead localhost —
    // the built-in resolver handles the command instead, so nothing
    // gets stuck or talks to a missing server.

    if (!aiOnline) {
        localFallback(command);
        return { ok: true, message: "Command received" };
    }

    try {

        const controller = new AbortController();
        const timeout = setTimeout(
            () => controller.abort(),
            8000
        );

        const response = await fetch(
            BACKEND_URL + "/command",

            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },

                signal: controller.signal,

                body: JSON.stringify({
                    command: command
                })
            }
        );

        clearTimeout(timeout);

        if (!response.ok) {

            throw new Error(
                "Backend error " + response.status
            );
        }

        const data = await response.json();

        if (
            !data.success ||
            !data.actions
        ) {

            throw new Error(
                data.error ||
                "Failed to parse the command"
            );
        }

        const actions = Array.isArray(data.actions)
            ? data.actions
            : [data.actions];

        const parts = [];

        for (const action of actions) {

            if (cancelled) {
                return { ok: false, message: "Cancelled" };
            }

            const executed =
                runAction(action);

            if (executed) {
                parts.push(describeAction(action));
            }
        }

        if (parts.length) {
            return { ok: true, message: parts.join(". ") };
        }

        return { ok: false, message: "Unsupported action" };

    } catch (error) {

        console.log(
            "Backend error:",
            error.message
        );

        if (cancelled) {
            return { ok: false, message: "Cancelled" };
        }

        // Works offline too - handles common commands locally
        localFallback(command);

        return { ok: true, message: "Command received" };
    }
}

// ======================================
// LOCAL RESOLVER
// ======================================

// Fast, offline resolver for the most common commands.
// Returns an action object, or null if it needs the AI.

// Big map of site aliases (nicknames, shorthands, number shortcuts).
// Every key maps to the URL to open. "open 1", "open yt", "open tube",
// "open face" etc. all resolve instantly - no AI needed.

const SITE_ALIASES = {
    // Numbers: quick shortcuts
    "1": "https://www.youtube.com",
    one: "https://www.youtube.com",
    "2": "https://www.google.com",
    two: "https://www.google.com",
    "3": "https://mail.google.com",
    three: "https://mail.google.com",
    "4": "https://chatgpt.com",
    four: "https://chatgpt.com",
    "5": "https://github.com",
    five: "https://github.com",
    "6": "https://www.facebook.com",
    six: "https://www.facebook.com",
    "7": "https://www.instagram.com",
    seven: "https://www.instagram.com",
    "8": "https://www.amazon.com",
    eight: "https://www.amazon.com",
    "9": "https://www.netflix.com",
    nine: "https://www.netflix.com",
    "10": "https://web.whatsapp.com",
    ten: "https://web.whatsapp.com",

    // YouTube
    youtube: "https://www.youtube.com",
    ytube: "https://www.youtube.com",
    yt: "https://www.youtube.com",
    tube: "https://www.youtube.com",

    // Google
    google: "https://www.google.com",
    ggl: "https://www.google.com",
    goggle: "https://www.google.com",

    // ChatGPT / OpenAI
    chatgpt: "https://chatgpt.com",
    gpt: "https://chatgpt.com",
    chadgpt: "https://chatgpt.com",
    openai: "https://openai.com",
    ai: "https://chatgpt.com",

    // Gmail
    gmail: "https://mail.google.com",
    mail: "https://mail.google.com",
    mailbox: "https://mail.google.com",

    // GitHub
    github: "https://github.com",
    git: "https://github.com",
    "git hub": "https://github.com",
    gh: "https://github.com",

    // Facebook
    facebook: "https://www.facebook.com",
    fb: "https://www.facebook.com",
    face: "https://www.facebook.com",
    meta: "https://www.facebook.com",

    // Instagram
    instagram: "https://www.instagram.com",
    insta: "https://www.instagram.com",
    ig: "https://www.instagram.com",
    gram: "https://www.instagram.com",

    // Amazon
    amazon: "https://www.amazon.com",
    amz: "https://www.amazon.com",

    // Netflix
    netflix: "https://www.netflix.com",
    nflx: "https://www.netflix.com",

    // Spotify
    spotify: "https://open.spotify.com",
    spot: "https://open.spotify.com",
    spoty: "https://open.spotify.com",

    // WhatsApp
    whatsapp: "https://web.whatsapp.com",
    whats: "https://web.whatsapp.com",
    wa: "https://web.whatsapp.com",

    // Twitter / X
    twitter: "https://twitter.com",
    tweet: "https://twitter.com",
    x: "https://x.com",

    // LinkedIn
    linkedin: "https://www.linkedin.com",
    linkin: "https://www.linkedin.com",
    linked: "https://www.linkedin.com",

    // Reddit
    reddit: "https://www.reddit.com",
    red: "https://www.reddit.com",

    // Wikipedia
    wikipedia: "https://www.wikipedia.org",
    wiki: "https://www.wikipedia.org",
    wikipidea: "https://www.wikipedia.org",

    // Stack Overflow
    stackoverflow: "https://stackoverflow.com",
    "stack overflow": "https://stackoverflow.com",
    stack: "https://stackoverflow.com",
    so: "https://stackoverflow.com",

    // Discord
    discord: "https://discord.com/channels/@me",
    dc: "https://discord.com/channels/@me",

    // TikTok
    tiktok: "https://www.tiktok.com",
    tt: "https://www.tiktok.com",

    // Twitch
    twitch: "https://www.twitch.tv",
    tw: "https://www.twitch.tv",

    // Pinterest
    pinterest: "https://www.pinterest.com",
    pin: "https://www.pinterest.com",

    // Maps / Drive / Docs
    "google maps": "https://maps.google.com",
    maps: "https://maps.google.com",
    map: "https://maps.google.com",
    "google drive": "https://drive.google.com",
    drive: "https://drive.google.com",
    "google docs": "https://docs.google.com/document",
    docs: "https://docs.google.com/document",

    // Misc popular
    gmailcom: "https://mail.google.com",
    "w3 schools": "https://www.w3schools.com",
    w3schools: "https://www.w3schools.com",
    claude: "https://claude.ai",
    gemini: "https://gemini.google.com",
    gmaildotcom: "https://mail.google.com"
};

// People you're in a DM with -> their Discord User ID.
// "nova call <nickname>" opens your DM with them and clicks
// the Voice Call button. Add nicknames + IDs here:
//   bestie: "123456789012345678"
// Get a User ID: Discord Settings > Advanced > Developer Mode,
// then right-click their name -> "Copy User ID".
const VOICE_TARGETS = {
    gay: "1454130615057256488",
    gayy: "1454130615057256488"
};

const OPEN_PREFIXES = ["open ", "go to ", "take me to ", "visit ", "launch ", "start ", "navigate to ", "open up ", "pull up "];
const SEARCH_PREFIXES = ["search ", "look up ", "find "];
// Question starters -> run an instant web search instead of the slow AI.
const QUESTION_STARTERS = [
    /^(what|what's|whats|who|who's|whos|when|where|why|how|is|are|can|does|do|did|tell me about|give me|latest|news on|explain|define|meaning of)\b/i
];

function resolveLocally(command) {

    const lower = " " + String(command).toLowerCase().trim() + " ";
    const trimmed = String(command).trim().toLowerCase();

    // Navigation / tab actions
    if (/\bnew tab\b/.test(lower)) return { action: "NEW_TAB" };

    // CLOSE - "close the tab" closes the last real tab; naming a
    // site ("close youtube", "close google") closes that site's tab(s).
    if (/\bclose\b/.test(lower)) {

        if (/\bclose (the|this|that|current|open)?\s*tab\b/.test(lower)) {
            return { action: "CLOSE_TAB" };
        }

        const closeName = trimmed
            .replace(/^close\b/, "")
            .replace(/^(the|that|this|my)\s+/i, "")
            .trim();

        if (closeName) {

            // Match a known site name / alias.
            for (const name in SITE_ALIASES) {
                if (/^\d+$/.test(name)) continue;
                if (
                    new RegExp(`\\b${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`).test(" " + closeName + " ")
                ) {
                    return { action: "CLOSE_TAB", target: name };
                }
            }

            // Match a spoken domain, e.g. "close discord.gg".
            const dom = closeName.match(
                /^([a-z0-9-]+(?:\.[a-z0-9-]+)+)$/
            );

            if (dom) {
                return {
                    action: "CLOSE_TAB",
                    url: "https://" + dom[1].toLowerCase()
                };
            }
        }
    }
    if (/\bgo back\b/.test(lower) || /\bback(page|wards)?\b/.test(lower)) return { action: "GO_BACK" };
    if (/\bgo forward\b/.test(lower) || /\bforward\b/.test(lower)) return { action: "GO_FORWARD" };
    if (/\breload\b/.test(lower) || /\brefresh\b/.test(lower)) return { action: "RELOAD" };
    if (/\bscroll\b/.test(lower)) {
        return { action: "SCROLL", direction: /\bup\b/.test(lower) ? "up" : "down" };
    }

    // VOLUME - control the video/audio playing on the current tab.
    // "volume up", "increase volume by half", "set volume to half",
    // "max the volume", "volume 30 percent", "mute", "unmute".
    if (
        /\bvolume\b/.test(lower) ||
        /\b(louder|quieter)\b/.test(lower) ||
        /\bmute\b/.test(lower) ||
        /\bunmute\b/.test(lower)
    ) {

        if (/\bmute\b/.test(lower) && !/\bunmute\b/.test(lower)) {
            return { action: "VOLUME", mode: "mute" };
        }

        if (/\bunmute\b/.test(lower)) {
            return { action: "VOLUME", mode: "unmute" };
        }

        const up =
            /\b(up|increase|raise|louder|higher|boost)\b/.test(lower);

        const down =
            /\b(down|decrease|reduce|lower|quieter|hush)\b/.test(lower);

        const step =
            /\bby (half|50)\b/.test(lower) ? 0.5 : 0.1;

        const pct =
            lower.match(/(\d{1,3})\s*(?:%|percent)/) ||
            lower.match(/\bvolume\s+(?:to |at )?(\d{1,3})\b/);

        if (pct) {
            return {
                action: "VOLUME",
                mode: "set",
                value: Math.max(0, Math.min(1, Number(pct[1]) / 100))
            };
        }

        if (/\b(max|maximum|full)\b/.test(lower)) {
            return { action: "VOLUME", mode: "set", value: 1 };
        }

        if (/\bhalf\b/.test(lower) && !/\bby half\b/.test(lower)) {
            return { action: "VOLUME", mode: "set", value: 0.5 };
        }

        if (up) {
            return { action: "VOLUME", mode: "up", step };
        }

        if (down) {
            return { action: "VOLUME", mode: "down", step };
        }

        return { action: "VOLUME", mode: "up", step: 0.1 };
    }

    // NEXT / PREVIOUS short - Shorts don't move by scrolling,
    // they use keyboard navigation (Down/ArrowDown = next,
    // ArrowUp = previous).
    if (
        /\bnext\b/.test(lower) ||
        /\bskip\b/.test(lower) ||
        /\bnext short(s)?\b/.test(lower) ||
        /\bnext one\b/.test(lower)
    ) {
        return { action: "NEXT_SHORT" };
    }
    if (
        /\bprevious\b/.test(lower) ||
        /\bprevious short(s)?\b/.test(lower) ||
        /\bprev\b/.test(lower) ||
        /\bgo back a (short|video)\b/.test(lower)
    ) {
        return { action: "PREV_SHORT" };
    }

    // SHORTS - "nova watch shorts" / "go to shorts" -> open the
    // YouTube Shorts feed. Scroll down/up with full-viewport
    // jumps to move between shorts.
    if (
        /\bshorts\b/.test(lower) ||
        /\b(?:watch|go to|open|browse|see)\s+shorts?\b/.test(lower) ||
        /\b(?:youtube|yt)\s+shorts?\b/.test(lower)
    ) {
        return {
            action: "OPEN_URL",
            url: "https://www.youtube.com/shorts"
        };
    }

    // CALL - "nova call gooner" (or "call my friend") -> open
    // the DM with that person and start a voice call.
    const callMatch = trimmed.match(
        /^(?:call|voice call|call up)\s+(.+)$/i
    );

    if (callMatch) {

        const who = callMatch[1]
            .replace(/\b(?:my friend|friend|my)\b/gi, " ")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();

        // Default to the first/only target, or match by name.
        let userId = null;
        let displayName = who || "your friend";

        if (who) {
            for (const name in VOICE_TARGETS) {
                if (
                    who === name ||
                    who.includes(name) ||
                    name.includes(who)
                ) {
                    userId = VOICE_TARGETS[name];
                    displayName = name;
                    break;
                }
            }
        }

        // No name given -> use the only entry.
        if (!userId && !who) {
            const keys = Object.keys(VOICE_TARGETS);
            if (keys.length === 1) {
                userId = VOICE_TARGETS[keys[0]];
                displayName = keys[0];
            }
        }

        if (userId) {
            return {
                action: "CALL_DM",
                userId,
                name: displayName
            };
        }

        return null;
    }

    // PLAY/PAUSE - control the video playing in the current tab.
    // "pause", "pause the video", "resume", "play the video", or a
    // bare "play" (with no song name) resumes it.
    if (/\b(pause|freeze|hold)\b/.test(lower)) {
        return { action: "PLAY_PAUSE", mode: "pause" };
    }

    if (
        /\b(resume|unpause|continue playing|keep playing)\b/.test(lower) ||
        /\bplay the (video|song|audio|music)\b/.test(lower)
    ) {
        return { action: "PLAY_PAUSE", mode: "play" };
    }

    if (
        /(^|\b)play(\s|$)/i.test(trimmed) &&
        !/\s+play\s+(\S)/.test(lower)
    ) {
        return { action: "PLAY_PAUSE", mode: "play" };
    }

    // PLAY - "nova play barsaat" -> search on YouTube and open
    // the most relevant (top) video, auto-playing it. Adding
    // "here" / "in this tab" reuses the current tab instead of
    // opening a new one.
    const playHere =
        /\b(?:here|in this tab|this tab)\b/.test(lower);

    const playMatch = trimmed
        .replace(/\b(?:here|in this tab|this tab)\b/gi, " ")
        .replace(/\s+/g, " ")
        .trim()
        .match(
            /^(?:play|watch|play the song)\s+(.+)$/i
        );

    if (playMatch) {
        const q = playMatch[1].trim();
        return { action: "PLAY", query: q, here: playHere };
    }

    // YouTube - search on YouTube
    if (/\bon youtube\b/.test(lower) || /\b(?:youtube|yt|tube)\b/.test(lower)) {
        if (/\bopen\b/.test(lower) && !/\bplay\b/.test(lower) && !/\bsearch\b/.test(lower)) {
            return { action: "OPEN_URL", url: SITE_ALIASES.youtube };
        }
        const q = String(command)
            .replace(/\b(hey nova|on youtube|on yt|youtube|yt|tube|play|watch|search)\b/gi, " ")
            .replace(/\s+/g, " ")
            .trim();
        return { action: "SEARCH", query: q || "youtube", engine: "youtube" };
    }

    // Alias / keyword -> OPEN_URL (when there's an open intent)
    for (const name in SITE_ALIASES) {
        if (new RegExp(`\\b${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`).test(lower)) {
            if (/\b(open|go to|take me to|visit|launch|start|navigate to|open up|pull up|show me)\b/.test(lower)) {
                return { action: "OPEN_URL", url: SITE_ALIASES[name] };
            }
        }
    }

    // Spoken URL -> OPEN_URL
    // e.g. "open discord.gg", "go to google.com"
    const domainMatch = trimmed.match(
        /^(?:open|go to|take me to|visit|launch|start|navigate to|open up|pull up)\s+([a-z0-9-]+(?:\.[a-z0-9-]+)+)\s*$/
    );

    if (domainMatch) {
        let url = domainMatch[1].toLowerCase();
        if (!/^https?:\/\//i.test(url)) {
            url = "https://" + url;
        }
        return { action: "OPEN_URL", url };
    }

    // Question -> instant SEARCH (avoids the slow Ollama call)
    if (QUESTION_STARTERS.some((re) => re.test(trimmed))) {
        return { action: "SEARCH", query: trimmed };
    }

    // Explicit search prefixes
    for (const p of SEARCH_PREFIXES) {
        if (trimmed.startsWith(p)) {
            return { action: "SEARCH", query: trimmed.replace(p, "").trim() };
        }
    }

    return null;
}


// ======================================
// RUN ACTION
// ======================================

function runAction(action) {

    switch (action.action) {

        case "OPEN_URL":

            if (action.url) {

                chrome.tabs.create({
                    url: action.url
                });

                return true;
            }

            break;


        case "CALL_DM":

            callOnDiscord(action.userId, action.name);

            return true;


        case "SEARCH":

            searchWeb(
                action.query,
                action.engine
            );

            return true;


        case "PLAY":

            playOnYouTube(action.query, action.here);

            return true;


        case "NEW_TAB":

            chrome.tabs.create({});

            return true;


        case "CLOSE_TAB":

            if (action.target || action.url) {

                closeNamedTab(action);

                return true;
            }

            runOnTargetTab(
                (tab) =>
                    chrome.tabs.remove(tab.id)
            );

            return true;


        case "GO_BACK":

            runOnTargetTab(
                (tab) =>
                    chrome.tabs.goBack(tab.id)
            );

            return true;


        case "GO_FORWARD":

            runOnTargetTab(
                (tab) =>
                    chrome.tabs.goForward(tab.id)
            );

            return true;


        case "RELOAD":

            runOnTargetTab(
                (tab) =>
                    chrome.tabs.reload(tab.id)
            );

            return true;


        case "PREV_SHORT":

            runOnTargetTab(
                (tab) =>
                    pressKey(tab.id, "ArrowUp")
            );

            return true;


        case "NEXT_SHORT":

            runOnTargetTab(
                (tab) =>
                    pressKey(tab.id, "ArrowDown")
            );

            return true;


        case "SCROLL":

            runOnTargetTab(
                (tab) => {

                    const direction =
                        action.direction === "up" ? -1 : 1;

                    chrome.scripting.executeScript({

                        target: {
                            tabId: tab.id
                        },

                        func: (dir) => {

                            // Full viewport scroll so it changes
                            // YouTube Shorts in one go (700px was
                            // not enough).
                            const amount =
                                Math.max(
                                    window.innerHeight,
                                    800
                                );

                            window.scrollBy({
                                top: dir * amount,
                                behavior: "smooth"
                            });
                        },

                        args: [direction]

                    }).catch(() => {
                        console.log("Cannot scroll this page");
                    });
                }
            );

            return true;


        case "VOLUME":

            adjustTabVolume(action);

            return true;


        case "PLAY_PAUSE":

            toggleMediaPlayback(action.mode);

            return true;

    }

    return false;
}


// Adjust the volume of the video/audio playing on the active tab.
// mode: up / down / set / mute / unmute.
// step: 0.1 = "by 1", 0.5 = "by half".
function adjustTabVolume(action) {

    chrome.tabs.query(
        { active: true, currentWindow: true },
        (tabs) => {

            const tabId = tabs && tabs[0] && tabs[0].id;

            if (tabId == null) {
                return;
            }

            chrome.scripting.executeScript(
                {
                    target: { tabId },

                    func: (mode, value, step) => {

                        const elements =
                            Array.from(
                                document.querySelectorAll("video, audio")
                            );

                        if (!elements.length) {
                            return { found: false };
                        }

                        const visible = elements.filter((el) => {
                            const r = el.getBoundingClientRect();
                            return r.width > 0 && r.height > 0;
                        });

                        const pool = visible.length ? visible : elements;

                        // Pick the biggest element (the one you're
                        // likely watching/listening to).
                        const target =
                            pool.sort((a, b) => {
                                const wa = a.offsetWidth * a.offsetHeight;
                                const wb = b.offsetWidth * b.offsetHeight;
                                return wb - wa;
                            })[0];

                        let volume = target.volume;

                        if (mode === "mute") {
                            volume = 0;
                            target.muted = true;
                        } else if (mode === "unmute") {
                            volume = Math.max(volume, 0.7);
                            target.muted = false;
                        } else if (mode === "up") {
                            volume = Math.min(1, volume + step);
                            target.muted = false;
                        } else if (mode === "down") {
                            volume = Math.max(0, volume - step);
                            target.muted = false;
                        } else if (mode === "set") {
                            volume = Math.max(0, Math.min(1, value));
                            target.muted = false;
                        }

                        target.volume = volume;

                        return {
                            found: true,
                            volume: Math.round(volume * 100)
                        };
                    },

                    args: [
                        action.mode,
                        action.value == null ? 0 : action.value,
                        action.step == null ? 0.1 : action.step
                    ]

                }
            ).catch(() => {
                console.log("Cannot adjust volume on this page");
            });
        }
    );
}


// Pause or play the video/audio actually playing on the active tab.
function toggleMediaPlayback(mode) {

    chrome.tabs.query(
        { active: true, currentWindow: true },
        (tabs) => {

            const tabId = tabs && tabs[0] && tabs[0].id;

            if (tabId == null) {
                return;
            }

            chrome.scripting.executeScript(
                {
                    target: { tabId },

                    func: (m) => {

                        const elements =
                            Array.from(
                                document.querySelectorAll("video, audio")
                            );

                        if (!elements.length) {
                            return { found: false };
                        }

                        const visible = elements.filter((el) => {
                            const r = el.getBoundingClientRect();
                            return r.width > 0 && r.height > 0;
                        });

                        const pool = visible.length ? visible : elements;

                        const target =
                            pool.sort((a, b) => {
                                const wa = a.offsetWidth * a.offsetHeight;
                                const wb = b.offsetWidth * b.offsetHeight;
                                return wb - wa;
                            })[0];

                        if (m === "pause") {
                            target.pause();
                        } else {
                            const p = target.play();
                            if (p && p.catch) p.catch(() => {});
                        }

                        return { found: true };
                    },

                    args: [mode]

                }
            ).catch(() => {
                console.log("Cannot control media on this page");
            });
        }
    );
}


// Dispatch a real keyboard event to the page so Shorts and
// media players respond to navigation (ArrowDown = next short,
// ArrowUp = previous short, etc.).
function pressKey(tabId, key) {

    chrome.scripting.executeScript(
        {
            target: { tabId },
            func: (k) => {

                const opts = {
                    key: k,
                    code: k,
                    keyCode: k === "ArrowDown" ? 40
                        : k === "ArrowUp" ? 38 : 0,
                    which: k === "ArrowDown" ? 40
                        : k === "ArrowUp" ? 38 : 0,
                    bubbles: true
                };

                const node =
                    document.activeElement ||
                    document.body ||
                    document.documentElement;

                node.dispatchEvent(
                    new KeyboardEvent("keydown", opts)
                );
                node.dispatchEvent(
                    new KeyboardEvent("keyup", opts)
                );
            },
            args: [key]
        }
    ).catch(() => {
        console.log("Cannot send key to this page");
    });
}


// ======================================
// SEARCH WEB
// ======================================

function searchWeb(query, engine) {

    const q = encodeURIComponent(
        String(query || "").trim()
    );

    let url;

    if (engine === "youtube") {

        url =
            "https://www.youtube.com/results?search_query=" +
            q;

    } else if (engine === "google") {

        url =
            "https://www.google.com/search?q=" +
            q;

    } else {

        // Default to Edge / Bing
        url =
            "https://www.bing.com/search?q=" +
            q;
    }

    chrome.tabs.create({
        url: url
    });
}

// "nova call gooner" - open your DM with that person
// (discord.com/channels/@me/<userId>) then, once Discord
// loads, click the Voice Call button to ring them.
function callOnDiscord(userId, name) {

    const dmUrl =
        "https://discord.com/channels/@me/" +
        userId;

    // The DM may already be open in a tab - reuse it instead of
    // always opening a duplicate.
    chrome.tabs.query({ url: "https://discord.com/*" }, (existing) => {

        let tabToUse = null;

        for (const t of existing) {
            if (t.id != null) {
                tabToUse = t;
                break;
            }
        }

        if (tabToUse) {
            chrome.tabs.update(tabToUse.id, { url: dmUrl, active: true });
            pollForCallButton(tabToUse.id);
        } else {
            chrome.tabs.create({ url: dmUrl }, (tab) => {
                if (tab && tab.id != null) {
                    pollForCallButton(tab.id);
                }
            });
        }
    });

    console.log(
        "Calling " + (name || userId) + " on Discord"
    );
}

function pollForCallButton(tabId) {

    // Wait for Discord to fully render the DM header, then click
    // the Voice Call button. Keeps trying for ~20s.
    const maxTries = 30;
    let tries = 0;

    const poll = setInterval(() => {

        tries++;

        chrome.scripting.executeScript(
            {
                target: { tabId },
                func: () => {

                    // A forceful click that React/Chromium actually
                    // honors - dispatches the full pointer + mouse
                    // + click event chain, not a plain .click().
                    function fireClick(node) {
                        if (!node) {
                            return false;
                        }
                        const rect = node.getBoundingClientRect();
                        const x = rect.left + rect.width / 2;
                        const y = rect.top + rect.height / 2;
                        const opts = {
                            bubbles: true,
                            cancelable: true,
                            composed: true,
                            clientX: x,
                            clientY: y,
                            button: 0
                        };
                        node.dispatchEvent(
                            new PointerEvent("pointerdown", opts)
                        );
                        node.dispatchEvent(
                            new MouseEvent("mousedown", opts)
                        );
                        node.dispatchEvent(
                            new PointerEvent("pointerup", opts)
                        );
                        node.dispatchEvent(
                            new MouseEvent("mouseup", opts)
                        );
                        node.dispatchEvent(
                            new MouseEvent("click", opts)
                        );
                        return true;
                    }

                    // 1) Voice call button in the DM header.
                    // Discord's aria-label is like "Call (User)"
                    // or just "Call" - match any that *starts*
                    // with "call".
                    const buttons = document
                        .querySelectorAll("button[aria-label]");

                    for (const b of buttons) {
                        const label =
                            String(b.getAttribute("aria-label") || "")
                                .toLowerCase();
                        if (
                            label === "call" ||
                            label.startsWith("call ") ||
                            label.includes("voice call") ||
                            label.includes("start voice call")
                        ) {
                            if (fireClick(b)) {
                                return true;
                            }
                        }
                    }

                    // 2) Fallback: the phone/call icon button,
                    // matched by its title attribute.
                    const titled = document
                        .querySelectorAll('[title]');

                    for (const t of titled) {
                        const title =
                            String(t.getAttribute("title") || "")
                                .toLowerCase();
                        if (
                            title === "voice call" ||
                            title.startsWith("call ")
                        ) {
                            if (fireClick(t)) {
                                return true;
                            }
                        }
                    }

                    return false;
                }
            },
            (res) => {

                const clicked =
                    res && res[0] && res[0].result;

                if (clicked) {
                    clearInterval(poll);
                    return;
                }

                if (tries >= maxTries) {
                    clearInterval(poll);
                }
            }
        );
    }, 700);
}

// "nova play barsaat" - fetch YouTube search results, grab the
// most relevant (first) video id, and open it as an autoplaying
// video. Falls back to the search page if it can't find one.
// When useSameTab is true the video opens in the CURRENT tab
// instead of a new one.
async function playOnYouTube(query, useSameTab) {

    const q = encodeURIComponent(
        String(query || "").trim()
    );

    const searchUrl =
        "https://www.youtube.com/results?search_query=" +
        q;

    const openTab = (url) => {

        if (useSameTab) {

            chrome.tabs.query(
                { active: true, currentWindow: true },
                (tabs) => {

                    if (tabs && tabs[0] && tabs[0].id) {
                        chrome.tabs.update(tabs[0].id, { url });
                        return;
                    }

                    chrome.tabs.create({ url });
                }
            );

            return;
        }

        chrome.tabs.create({ url });
    };

    try {

        const response =
            await fetch(searchUrl);

        const html =
            await response.text();

        // YouTube embeds the results as JSON containing
        // "videoId":"XXXX" for each video.
        const match =
            html.match(/"videoId":"([a-zA-Z0-9_-]{11})"/);

        if (match && match[1]) {

            openTab(
                "https://www.youtube.com/watch?v=" +
                match[1]
            );

            return;
        }

    } catch (e) {
        console.log("Play fetch failed:", e);
    }

    // Fallback - just open the search results.
    openTab(searchUrl);
}


// ======================================
// TARGET TAB
// ======================================

// The voice page runs in its own tab, so we
// must act on the last real website tab instead.

function runOnTargetTab(callback) {

    const extensionUrl =
        chrome.runtime.getURL("");

    chrome.tabs.query({}, (tabs) => {

        const candidates = tabs.filter(
            (t) => {
                if (t.id == null || !t.url) {
                    return false;
                }
                return (
                    !t.url.startsWith(extensionUrl) &&
                    !t.url.startsWith("chrome://") &&
                    !t.url.startsWith("chrome-extension://") &&
                    !t.url.startsWith("edge://") &&
                    !t.url.startsWith("http://localhost:3000")
                );
            }
        );

        const target =
            candidates[candidates.length - 1];

        if (target) {

            callback(target);

        } else {

            const message =
                "No website tab to act on";

            result.textContent = message;

            speak(message);
        }
    });
}


// Close the tab(s) for a named site, e.g. "close youtube".
// action.target = SITE_ALIASES key, action.url = explicit domain.
function closeNamedTab(action) {

    const url =
        action.url ||
        (action.target && SITE_ALIASES[action.target]
            ? SITE_ALIASES[action.target]
            : null);

    if (!url) {
        const message = "Which website should I close";
        result.textContent = message;
        speak(message);
        return;
    }

    const key = String(url)
        .replace(/^https?:\/\//i, "")
        .replace(/\/.*$/, "");

    chrome.tabs.query({}, (tabs) => {

        const close = (tabs || []).filter((t) =>
            t.id != null &&
            t.url &&
            t.url.includes(key)
        );

        if (close.length) {

            chrome.tabs.remove(close.map((t) => t.id));

        } else {

            const message =
                "No " + siteName(url) + " tab open";

            result.textContent = message;

            speak(message);
        }
    });
}


// ======================================
// LOCAL FALLBACK
// ======================================

// Used when the AI backend is not running,
// so common commands still work.

function localFallback(command) {

    const lower =
        command.toLowerCase();

    const commonSites = {
        youtube: "https://www.youtube.com",
        google: "https://www.google.com",
        chatgpt: "https://chatgpt.com",
        gmail: "https://mail.google.com",
        github: "https://github.com",
        facebook: "https://www.facebook.com",
        instagram: "https://www.instagram.com",
        amazon: "https://www.amazon.com",
        netflix: "https://www.netflix.com",
        spotify: "https://open.spotify.com",
        whatsapp: "https://web.whatsapp.com"
    };

    for (const name in commonSites) {

        if (lower.includes(name)) {

            chrome.tabs.create({
                url: commonSites[name]
            });

            return;
        }
    }

    let searchText = command;

    const prefixes =
        ["search ", "google ", "look up ", "find "];

    for (const p of prefixes) {

        if (lower.startsWith(p)) {

            searchText =
                lower.replace(p, "").trim();

            break;
        }
    }

    searchWeb(searchText, null);
}


// ======================================
// FEEDBACK
// ======================================

// Turns a URL into a friendly spoken site name,
// e.g. "https://www.youtube.com" -> "YouTube",
// "https://mail.google.com" -> "Google".
function siteName(url) {

    try {

        let host = String(url)
            .replace(/^https?:\/\//i, "")
            .replace(/^www\./i, "")
            .split("/")[0];

        const parts = host.split(".");

        // "mail.google.com" -> "google", "youtube.com" -> "youtube"
        if (parts.length >= 3 && !/^\d+$/.test(parts[0])) {
            host = parts[parts.length - 2];
        }

        return host || "that site";

    } catch (e) {
        return "that site";
    }
}

function describeAction(action) {

    switch (action.action) {

        case "OPEN_URL":

            return "Opening " + siteName(action.url);

        case "SEARCH":

            return (
                "Searching " +
                (action.engine === "youtube" ? "YouTube" : "the web") +
                " for " + action.query
            );

        case "CALL_DM":

            return "Calling " + (action.name || "your friend");

        case "PLAY":

            return "Playing " + action.query;

        case "NEW_TAB":
            return "Opening a new tab";

        case "CLOSE_TAB":
            if (action.target && SITE_ALIASES[action.target]) {
                return "Closing " +
                    siteName(SITE_ALIASES[action.target]);
            }
            if (action.url) {
                return "Closing " + siteName(action.url);
            }
            return "Closing the current tab";

        case "PLAY_PAUSE":
            return action.mode === "pause"
                ? "Pausing the video"
                : "Playing the video";

        case "GO_BACK":
            return "Going back";

        case "GO_FORWARD":
            return "Going forward";

        case "RELOAD":
            return "Reloading the page";

        case "SCROLL":
            return "Scrolling " +
                (action.direction === "up" ? "up" : "down");

        case "VOLUME":
            if (action.mode === "mute") return "Muted";
            if (action.mode === "unmute") return "Volume on";
            if (action.mode === "up") return "Volume up";
            if (action.mode === "down") return "Volume down";
            if (action.value == null) return "Setting volume";
            return "Setting volume to " +
                Math.round(action.value * 100) + "%";

        case "NEXT_SHORT":
            return "Next short";

        case "PREV_SHORT":
            return "Previous short";

        default:
            return "Command received";
    }
}

function speak(message) {

    try {

        const utterance =
            new SpeechSynthesisUtterance(message);

        // Remember what Nova said so the echo-suppression in
        // onresult can ignore her own voice if it's picked up.
        lastSpokenText = message.toLowerCase().trim();

        utterance.lang = "en-US";
        utterance.volume = 1.0;
        utterance.rate = 1.0;
        utterance.pitch = 1.0;

        speechSynthesis.cancel();

        speechSynthesis.speak(utterance);

    } catch (error) {
        console.log(error);
    }
}